#include "hashtable.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

//key = combo of two char* (word, ID)
//value = num_occurrences
#define MAX 

struct hashtable* training()
{
    int num_buckets;
    printf("How many buckets would you like?: ");
    scanf("%d", &num_buckets);

    struct hashtable *ht = malloc(sizeof(struct hashtable)*1); //allocate memory on heap for a HashMap.  hm points to hashmap
    ht->num_buckets = num_buckets; //assigns the amount specified in test.c to num_buckets
    ht->map = malloc(sizeof(struct llnode*)*(ht->num_buckets)); //allocate num_buckets number of buckets
    for(int i = 0; i < ht->num_buckets; i++) //go through all buckets
    {
        ht->map[i] = (struct llnode*)malloc(sizeof(struct llnode)); //for each bucket, allocate a llnode
        ht->map[i]->word = NULL; //set the word = NULL for now
        ht->map[i]->next = NULL; //the end of the list is null
    }


    //scan each of the three files into the hashtable
    inputFileIntoHashTable("./p5docs/D1.txt", ht);
    inputFileIntoHashTable("./p5docs/D2.txt", ht);
    inputFileIntoHashTable("./p5docs/D3.txt", ht);

    //ht_print(ht); you can call this function to view the hashtable before and after removing stop words
    stop_word(ht); //remove the stop words
    //ht_print(ht);
    
    return ht;
}

void read_query(struct hashtable* ht, char* query) //reads user search
{
    char *ptr = strtok(query, " "); //separete by spaces

    while(ptr != NULL)
    {   
        //printf("%s\n", ptr);
        rank(ht, ptr);

        ptr = strtok(NULL, " "); 
    
    }
    double rank_docs[3];
    get_ranks(&rank_docs[0], &rank_docs[1], &rank_docs[2]);
    FILE *outptr;
    outptr = fopen("search_scores.txt","w");
        
        if(rank_docs[0] >= rank_docs[1])   
        {
            
            if(rank_docs[1] >= rank_docs[2]) 
            {
                if(rank_docs[1] == 0 &&  rank_docs[2] == 0 && rank_docs[0] > 0)  
                {
                    fprintf(outptr, "D1.txt: %f\n",  rank_docs[0]);
                }
                else if(rank_docs[1] == 0 &&  rank_docs[2] == 0 && rank_docs[0] == 0)
                {
                    fprintf(outptr, "No Matches");
                }
                
                else if(rank_docs[2] == 0 && rank_docs[0] > 0 && rank_docs[1] > 0) 
                {
                    fprintf(outptr, "D1.txt: %f\n", rank_docs[0]);
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                }
                else
                {
                    fprintf(outptr, "D1.txt: %f\n", rank_docs[0]);
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);
                }
                
            }
            else if(rank_docs[0] >= rank_docs[2]) 
            {
         
                if(rank_docs[1] == 0 && rank_docs[0] > 0 && rank_docs[2] > 0) 
                {
                    fprintf(outptr, "D1.txt: %f\n", rank_docs[0]);
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);
                }
                else
                {
                    fprintf(outptr, "D1.txt: %f\n", rank_docs[0]);
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                }
                
            }
            else
            {
                if(rank_docs[0] == 0 &&  rank_docs[1] == 0 && rank_docs[2] > 0) 
                {
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);
                }
                else
                {
                    fprintf(outptr, "D3.txt: %f\n", rank_docs[2]);
                    fprintf(outptr, "D1.txt: %f\n",  rank_docs[0]);
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                }
                
            }
        }
        else //first element not greater than second element   
        {
            if(rank_docs[0] >= rank_docs[2]) 
            {
                if(rank_docs[0] == 0 &&  rank_docs[2] == 0 && rank_docs[1] > 0) 
                {
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                }
                else if(rank_docs[2] == 0 && rank_docs[0] > 0 && rank_docs[1] > 0)
                {
                    fprintf(outptr, "D2.txt: %f\n", rank_docs[1]);
                    fprintf(outptr, "D1.txt: %f\n",  rank_docs[0]);
                }
                else
                {
                    fprintf(outptr, "D2.txt: %f\n", rank_docs[1]);
                    fprintf(outptr, "D1.txt: %f\n",  rank_docs[0]);
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);
                }
                
            }
            else if(rank_docs[1] >= rank_docs[2]) //second score is >= third score
            {
                if(rank_docs[0] == 0 && rank_docs[1] > 0 && rank_docs[1] > 0)
                {
                    fprintf(outptr, "D2.txt: %f\n", rank_docs[1]);
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);

                }
                else
                {
                    fprintf(outptr, "D2.txt: %f\n", rank_docs[1]);
                    fprintf(outptr, "D3.txt: %f\n",  rank_docs[2]);
                    fprintf(outptr, "D1.txt: %f\n",  rank_docs[0]);
                }
            }
                
            else 
            {
                if(rank_docs[0] == 0 && rank_docs[1] > 0 && rank_docs[1] > 0)
                {
                    fprintf(outptr, "D3.txt: %f\n", rank_docs[2]);
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                }
                else
                {
                    fprintf(outptr, "D3.txt: %f\n", rank_docs[2]);
                    fprintf(outptr, "D2.txt: %f\n",  rank_docs[1]);
                    fprintf(outptr, "D1.txt: %f\n",  rank_docs[0]);
                }

                
            }

        }
        
    return;
}

double rank(struct hashtable* ht, char *ptr)
{
    if(ht != NULL) 
    {
        int slot = hash_code(ht, ptr); //determines which bucket to look in using hash function
        struct llnode *node = ht->map[slot]; //ptr points to beginning of a certain bucket
        double tf1 = 0; //default, tfs are set to 0;
        double tf2 = 0;
        double tf3 = 0;
        double idf;
        double tfIDF1;
        double tfIDF2;
        double tfIDF3;
        
        if(ptr == NULL) //nothing in the bucket
        {
            return 0; 
        }
        else // Bucket is not null
        {
            while(1)
            {
                
                if(strcmp(node->word, ptr) == 0 && strcmp(node->document_id, "./p5docs/D1.txt") == 0) //Word exists in D1
                {  
                    tf1 = node->num_occurrences;
                }
                if(strcmp(node->word, ptr) == 0 && strcmp(node->document_id, "./p5docs/D1.txt") != 0) //Word does not exist in D1
                {
                    tf1 = 0.0;
                }
    
                if(strcmp(node->word, ptr) == 0 && strcmp(node->document_id, "./p5docs/D2.txt") == 0) ///Word exists in D2
                {
                    tf2 = node->num_occurrences;
                }
                if(strcmp(node->word, ptr) == 0 && strcmp(node->document_id, "./p5docs/D2.txt") != 0) //Word does not exist in D2
                {
                    tf2 = 0.0;
                }
       
                if(strcmp(node->word, ptr) == 0 && strcmp(node->document_id, "./p5docs/D3.txt") == 0) //Word exists in D3
                {
                    tf3 = node->num_occurrences;
                }
                if(strcmp(node->word, ptr) == 0 && strcmp(node->document_id, "./p5docs/D3.txt") != 0) //Word does not exist in D3
                {
                    tf3 = 0.0;
                } 
                
                if(node->next == NULL) //if the end of the list is reached
                {
                    break;
                }
                
                node = node->next;
                
            
            }
            
            idf = calculateIDF(ht, ptr); //calculate IDF of this word

            //calculate tf-idf scores
            tfIDF1 = tf1 * idf;
            tfIDF2 = tf2 * idf;
            tfIDF3 = tf3 * idf;
    
            //add the scores to an array to keep track of the data
            addNode(tfIDF1, tfIDF2, tfIDF3);
            
        }
        
        return tfIDF1;
    }
    else //hm is null
    {
        return 0;
    }
    
    return 0;
    
}

struct tfIDFnode word_array[100];  //array of query words (set to 100)
int words_inserted = 0; //keeps track of how many words are in query


void addNode(double tfIDF1, double tfIDF2, double tfIDF3)
{
    
    struct tfIDFnode node; //node to store information 
    node.tfIDF1 = tfIDF1; 
    node.tfIDF2 = tfIDF2;
    node.tfIDF3 = tfIDF3;

    word_array[words_inserted] = node; //insert the tf-idf scores into the array
    words_inserted += 1;
    //print_array(); //print out the array to visualize

    return;
}

void get_ranks(double *r1, double *r2, double *r3) //calculates rank scores for the documents
{
    //default set to 0
    *r1 = 0;
    *r2 = 0;
    *r3 = 0;
    
    for(int i = 0; i < words_inserted; i++)
    {
        *r1 += word_array[i].tfIDF1; //sum of the tf-idf scores in the first column
        *r2 += word_array[i].tfIDF2; //sum of the tf-idf scores in the second column
        *r3 += word_array[i].tfIDF3; //sum of the tf-idf scores in the third column

    }
}

/*
void print_array() //function used to view the contents of the array with the rank scores (not necessary, but good for checking)
{
    int i = 0;
    printf("------- contents -----\n");
    for(; i < words_inserted; i++)
    {
        printf("%d, %f, %f, %f\n", i, word_array[i].tfIDF1, word_array[i].tfIDF2, word_array[i].tfIDF3);
    }
}
*/


double calculateIDF(struct hashtable* ht, char* ptr)
{
    double idf;
    int N = 3; //number of documents
    double df; // number of docs that contain the specific word
       
            
                //use get function to see how many times the word appears in each document
                int x = ht_get(ht, ptr, "./p5docs/D1.txt");
                int y = ht_get(ht, ptr, "./p5docs/D2.txt");
                int z = ht_get(ht, ptr, "./p5docs/D3.txt");

            
                //appears 0 times accross all docs
                if((x == 0) && (y == 0) && (z == 0))
                {
                    df = 0.0;
                }
                //appears once across all docs
                if(((x > 0) && (y == 0) && (z == 0)) || ((x == 0) && (y > 0) && (z == 0)) || ((x == 0) && (y == 0) && (z > 0)))
                {
                    df = 1.0;
                }
                //appears twice across all docs
                if(((x > 0) && (y > 0) && (z == 0)) || ((x > 0) && (y == 0) && (z > 0)) || ((x == 0) && (y > 0) && (z > 0)))
                {
                    df = 2.0;
                }
                //appears in all of the documents
                if((x > 0) && (y > 0) && (z > 0)) 
                {
                    df = 3.0;
                }
    
              
                //compute idf of each node
                if(df != 0.0)
                {
                    idf = (double)log10(N/df);
                }
                else
                {
                    idf = (double)log10(N/(df + 1)) ;
                }


    return idf;
        
}



struct hashtable* stop_word(struct hashtable* ht) //used to find words with an idf of 0 and removes them
{

    if (ht == NULL) //if the hashtable is empty
    {
        return ht;   
    }
    else //hashtable not empty
    {
        for(int i = 0; i < ht->num_buckets; i++) //go through each bucket in ht
        {
            struct llnode *node = ht->map[i];
            struct llnode *prev = node;
    
            while(node != NULL)   //traverse each linked list
            {   
                if(node->word != NULL)
                {
                    double idf = calculateIDF(ht, node->word); //calculate idf score
                    
            
                    //if idf = 0, remove word from list
                    if(idf == 0)
                    {
                        ht_remove(ht, node->word); //remove word
                    }
                }
                prev = node;
                node = node->next; //move node one over in the bucket
            }
        
        }
       
    }
    
    return ht;
        
}


void inputFileIntoHashTable(char *fileName, struct hashtable *ht)
{
        FILE *dataFile; //file pointer
        dataFile = fopen(fileName, "r"); //open the file for reading
        char textWord[100]; 
    
        if(dataFile == NULL) //if file is empty/dne
        {
                printf("Cannot open file\n");
        }

        else
        {
                while(fscanf(dataFile, "%s", textWord) != EOF) //scan in the words of the file
                {
                        hash_table_insert(ht, textWord, fileName,1); //puts each word from the file into hm
                      
                }
        }
}



int hash_code(struct hashtable* ht, const char* word)
//take the given word and doc ID and map them to a bucket in the HashMap
//sum the ASCII codes of all the chars then mod by num buckets
{   

    int S = 0; 
    int N = ht->num_buckets;
    if((ht != NULL)&&(word != NULL))
    {
        int wordLength = strlen(word);
        for(int i = 0; i < wordLength; i++)
        {
            S += (int)word[i];
        }

    }
    int b = S % N;
    return b;
}



void hash_table_insert(struct hashtable* ht, const char* word, char* document_id, int num_occurrences)
{
    int slot = hash_code(ht, word); //determines which bucket to look in
    struct llnode *node = ht->map[slot]; //node points to the beginning of that bucket
    
    if(node->word == NULL || node->document_id == NULL) //if the bucket is empty so far
    {
        //enter the information of the node (word, doc_id, num_occurrences)
        node->word = strdup(word); //returns a pointer to a duplicate of the word
        node->document_id = strdup(document_id); //returns a pointer to a duplicate of the id
        node->num_occurrences = num_occurrences;
        node->next = NULL;
        return;
    }
    else //something already exists in the bucket
    {
        int found = 0;
        while(1)
        {
            if(strcmp(node->word, word) == 0 && strcmp(node->document_id, document_id) == 0) //if there is a match
            {
                //increment the num_occurrences
                node->num_occurrences += num_occurrences; //replaces the number of occurrences
                //this overwrites the prev value
                found = 1;
                return;
            }
            if(node->next==NULL)
            {
                break;
            }
            node = node->next;
        }
        if(found == 0){ //the elements do not exist yet in the bucket
            //insert new element
            struct llnode* node2 = malloc(sizeof(struct llnode)); //create another node
            //add these elements to the new node
            node2->word = strdup(word); 
            node2->document_id = strdup(document_id);
            node2->num_occurrences = num_occurrences;
            node2->next = NULL;
            node->next = node2; //this node will come after the others
        }
        

    }
    
}

/*
void ht_print(struct hashtable *ht) //used to see what is inside the hashtable for testing (not necessary for functionality)
{
    if(ht==NULL){
        return;
    }
    
    for(int i = 0; i < ht->num_buckets; i++) //go thru each bucket
    {
        struct llnode* node = ht->map[i]; //node points to the bucket
        while(1){ 
        
            printf("i:%d, buckets:%d, word:%s, numoc: %d, doc_id: %s\n",i, ht->num_buckets,node->word, node->num_occurrences, node->document_id); //prints the info
            if( node->next == NULL){
                break;
            }
            node = node->next;

        }
        
    }
}
*/


int ht_get(struct hashtable* ht, char* word, char* document_id) 
//return the value associated with the key passed in within Hashtable passed in
{
    if(ht != NULL) //if there are elements inside the hashmap to get
    {
        int slot = hash_code(ht, word); //determines which bucket to look in using hash function
        struct llnode *ptr = ht->map[slot]; //ptr points to beginning of a certain bucket
        if(ptr == NULL)
        {
            return 0; //nothing in the bucket
        }
        else
        {
            while(1){
                if(strcmp(ptr->word, word) == 0 && strcmp(ptr->document_id, document_id) == 0) //if the word & id you are looking for is found
                {
                    return ptr->num_occurrences;    //return the num_occurrences
                }

                if(ptr->next == NULL){
                    break;
                }
                ptr = ptr->next; //move to next node

            }
            
        }
        return 0;
    }
    else //hm is null
    {
        return 0;
    }
    

}


void ht_remove(struct hashtable* ht, const char* word) 
//remove the value associated with the key passed in within Hashtable passed in
{
    //printf("trying to remove %s\n",word);
    if(ht != NULL) //if there are elements inside the hashmap to get
    {
        int slot = hash_code(ht, word); //determines which bucket to look in using hash function
        struct llnode *ptr = ht->map[slot]; //ptr points to beginning of a certain bucket
        struct llnode *prev = ptr;
        struct llnode *tmp = NULL;

        if(ptr == NULL)
        {
            printf("nothing in bucket\n");
            return; //nothing in the bucket
        }
        else
        {
            while(1)
            {
                if(strcmp(ptr->word, word) == 0) //if the word you are looking for is found
                {
                    
                    if(ptr == ht->map[slot]) //word is the head of the bucket
                    {
                        ht->map[slot] = ptr->next; //unlink that word from list
                        prev = ptr;
                    }
                    else
                    {
                        prev->next = ptr->next; //unlink word from list
                    }
                    tmp = ptr;
                    ptr = ptr->next;
                   
                }
                else
                {
                    prev = ptr;
                    ptr = ptr->next; //no match, go to to next node
                }
                
                if(ptr == NULL)
                {
                    break;
                }

            }
            return;
            
        }
        return;
    }
    else //hm is null
    {
        return;
    }
}

   
