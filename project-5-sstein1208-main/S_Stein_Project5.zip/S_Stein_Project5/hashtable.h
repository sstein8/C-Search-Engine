#ifndef HASHTABLE_H
#define HASHTABLE_H

struct llnode {
        char* word;
        char* document_id;
        int num_occurrences;
        struct llnode* next;
};

struct hashtable {
        struct llnode** map; //like buckets
        int num_buckets;
        int num_elements;
};
/*
struct LList
{
  struct tfIDFnode *head;
};
*/

struct tfIDFnode {
        double tfIDF1;
        double tfIDF2;
        double tfIDF3;
        struct tfIDFnode* next;
};


struct hashtable* training(void);
void hash_table_insert(struct hashtable* ht, const char* word, char* document_id, int num_occurrences);
int hash_code(struct hashtable* ht, const char* word);
int ht_get(struct hashtable* ht, char* word, char* document_id);
//void ht_print(struct hashtable *ht); //you can call this if you want to visualize the hashtable
void inputFileIntoHashTable(char *fileName, struct hashtable *ht);
struct hashtable* stop_word(struct hashtable* ht);
void ht_remove(struct hashtable* ht, const char* word);
void read_query(struct hashtable* ht, char* query);
double rank(struct hashtable* ht, char *ptr);
double calculateIDF(struct hashtable* ht, char* ptr);
void addNode(double tfIDF1, double tfIDF2, double tfIDF3);
//void print_array(void); //you can call this if you want to view the array
void get_ranks(double *r1, double *r2, double *r3);


#endif
