#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "hashtable.h"

#define MAX_WORDS 500

int main(void)
{
    
   //training();
   struct hashtable* ht = training();


   //search/retreival
   char query[100];
   printf("Enter search string or X to exit: "); //takes in a max of 100 words (this number is determined when I made the array, so I chose 100 as the value)
   scanf(" %[^\t\n]s", query); //separetes words by spaces
   if(strcmp(query, "X") == 0) //if user enters X
   {
      exit(0);
   }
   else
   {
      //printf("read query should be here\n");
      read_query(ht, query);
   }
   

return 0;
}
